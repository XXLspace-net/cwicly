=== Cwicly ===
Contributors: cwicly
Requires at least: 5.9
Tested up to: 6.2.2
Requires PHP: 5.6
Stable tag: 1.0.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Official Theme for the Ultimate Gutenberg Toolkit.

The **ultimate** toolkit that takes Gutenberg by WordPress to the next level and makes it become a professional drag & drop website builder. 

Design & create **professional responsive** websites in minutes.

Introducing the ultimate WordPress & Gutenberg toolkit. A **toolkit** that allows you to create and edit high-end professional responsive websites with **ease**.

Check out the **[Cwicly Gutenberg Toolkit](https://cwicly.com/?utm_source=wp-admin-about&utm_medium=link&utm_campaign=readme)**.

== Changelog ==

To read the changelog for Cwicly, please navigate to the <a href="https://discourse.cwicly.com/c/changelog/12">changelog page</a>.